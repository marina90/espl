version = (1, 6, 3)
version_string = ".".join(map(str,version))
release_date = "2016.12.31"
